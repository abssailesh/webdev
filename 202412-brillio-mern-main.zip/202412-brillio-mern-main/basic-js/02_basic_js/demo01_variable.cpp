int main(){
    int x=20;
    x=30; //OK
    x="hello"; //NOT OK.
}