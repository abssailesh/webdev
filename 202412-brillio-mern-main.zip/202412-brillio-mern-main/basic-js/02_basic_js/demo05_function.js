function greet(name){
    console.log(`Hello ${name}, Welcome to JavaScript!`)
}

var result=greet('Brillio')

console.log('result',result);
