
var x=20; //ES5
let y=20; //ES2015
const z=30; //ES2015

console.log('x',x);

x=30; //OK
console.log('x',x);

x='Hello World';
console.log('x',x);


y=20.5;
console.log('y',y);


//z=60;

console.log('z',z);
