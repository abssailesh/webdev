
x='Hello'

print(x)

address='''Mahaveer Ranches
Hosa Road
Bangalore'''

print(address);

x=20
y=30

output = f'sum of {x} and {y} is {x+y}'

print(output);