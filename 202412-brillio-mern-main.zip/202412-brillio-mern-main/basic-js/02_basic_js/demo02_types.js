

let a=20;
console.log(typeof(a),a);

let b=20.5;
console.log(typeof(b),b);

b="x";
console.log(typeof(b),b);

b='Hello World';
console.log(typeof(b),b);

b=`Mahaveer Ranches,
Hosa Road`;

let x=20;
let y=30;

let output=`sum of ${x} and ${y} is ${x+y}`;
console.log(output);


console.log(typeof(b),b);


let z= true;

console.log(typeof(z),z);

z=2>3;

console.log(typeof(z),z);

z= new Object();

console.log(typeof(z),z);

z={}; //same as new Object()

console.log(typeof(z),z);

var d=new Date();

console.log(typeof(d),d);

var list=[2,3,'hello', false, new Date()];

console.log(typeof(list),list);

let c=null;

console.log(typeof(c),c);

let e=undefined; //explicitly undefined

console.log(typeof(e),e);

let f; //implicitly undefined.

console.log(typeof(f),f);

