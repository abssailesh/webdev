function print(x){
    for(let i =0;i<arguments.length;i++){
        console.log(arguments[i]);
    }
    
}

print(1,2,3,4); //x=1  arguments: 1,2,3,4
