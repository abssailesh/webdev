console.log(`invalid operator: '${operator}'`);
            return;